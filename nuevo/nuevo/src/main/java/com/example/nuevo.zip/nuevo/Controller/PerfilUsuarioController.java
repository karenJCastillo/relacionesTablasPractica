package com.example.nuevo.Controller;

import com.example.nuevo.Model.PerfilUsuario;
import com.example.nuevo.Service.PerfilUsuarioService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/perfiles")
public class PerfilUsuarioController {

    private final PerfilUsuarioService perfilUsuarioService;

    public PerfilUsuarioController(PerfilUsuarioService perfilUsuarioService) {
        this.perfilUsuarioService = perfilUsuarioService;
    }

    // GET /api/perfiles
    @GetMapping
    public ResponseEntity<List<PerfilUsuario>> listar() {
        List<PerfilUsuario> perfiles = perfilUsuarioService.listarTodos();
        return ResponseEntity.ok(perfiles);
    }

    // GET /api/perfiles/{id}
    @GetMapping("/{id}")
    public ResponseEntity<PerfilUsuario> buscar(@PathVariable Long id) {
        try {
            PerfilUsuario perfil = perfilUsuarioService.buscarPorId(id);
            return ResponseEntity.ok(perfil);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // GET /api/perfiles/usuario/{usuarioId}
    @GetMapping("/usuario/{usuarioId}")
    public ResponseEntity<PerfilUsuario> buscarPorUsuario(@PathVariable Long usuarioId) {
        try {
            PerfilUsuario perfil = perfilUsuarioService.buscarPorUsuarioId(usuarioId);
            return ResponseEntity.ok(perfil);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // POST /api/perfiles
    @PostMapping
    public ResponseEntity<PerfilUsuario> crear(@RequestBody PerfilUsuario perfil) {
        try {
            PerfilUsuario nuevo = perfilUsuarioService.guardar(perfil);
            return ResponseEntity.status(HttpStatus.CREATED).body(nuevo);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    // PUT /api/perfiles/{id}
    @PutMapping("/{id}")
    public ResponseEntity<PerfilUsuario> actualizar(@PathVariable Long id, @RequestBody PerfilUsuario perfil) {
        try {
            PerfilUsuario actualizado = perfilUsuarioService.actualizar(id, perfil);
            return ResponseEntity.ok(actualizado);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // DELETE /api/perfiles/{id}
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        try {
            perfilUsuarioService.eliminar(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
