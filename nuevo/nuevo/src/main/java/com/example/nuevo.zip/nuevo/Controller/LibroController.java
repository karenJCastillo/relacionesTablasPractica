package com.example.nuevo.Controller;

import com.example.nuevo.Model.Libro;
import com.example.nuevo.Service.LibroService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/libros")
public class LibroController {

    private final LibroService libroService;

    public LibroController(LibroService libroService) {
        this.libroService = libroService;
    }

    // GET /api/libros
    @GetMapping
    public ResponseEntity<List<Libro>> listar() {
        List<Libro> libros = libroService.listarTodos();
        return ResponseEntity.ok(libros);
    }

    // GET /api/libros/{id}
    @GetMapping("/{id}")
    public ResponseEntity<Libro> buscar(@PathVariable Long id) {
        try {
            Libro libro = libroService.buscarPorId(id);
            return ResponseEntity.ok(libro);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // GET /api/libros/categoria/{categoriaId}
    @GetMapping("/categoria/{categoriaId}")
    public ResponseEntity<List<Libro>> listarPorCategoria(@PathVariable Long categoriaId) {
        List<Libro> libros = libroService.listarPorCategoria(categoriaId);
        return ResponseEntity.ok(libros);
    }

    // GET /api/libros/autor/{autor}
    @GetMapping("/autor/{autor}")
    public ResponseEntity<List<Libro>> listarPorAutor(@PathVariable String autor) {
        List<Libro> libros = libroService.listarPorAutor(autor);
        return ResponseEntity.ok(libros);
    }

    // POST /api/libros
    @PostMapping
    public ResponseEntity<Libro> crear(@RequestBody Libro libro) {
        try {
            Libro nuevo = libroService.guardar(libro);
            return ResponseEntity.status(HttpStatus.CREATED).body(nuevo);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    // PUT /api/libros/{id}
    @PutMapping("/{id}")
    public ResponseEntity<Libro> actualizar(@PathVariable Long id, @RequestBody Libro libro) {
        try {
            Libro actualizado = libroService.actualizar(id, libro);
            return ResponseEntity.ok(actualizado);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // DELETE /api/libros/{id}
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        try {
            libroService.eliminar(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
